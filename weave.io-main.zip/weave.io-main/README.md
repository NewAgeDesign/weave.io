# weave.io
This is a SAAS web builder created fully with HTML, CSS, JS, PHP, and MySQL, with collaborative features, figma drag and drop features, and in future, project management features, AI support, fully functional no code frontend and backend interaction, project documentation and Export (launch), have ideas? add them in the readme file
